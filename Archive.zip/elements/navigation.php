<?php defined('C5_EXECUTE') or die("Access Denied."); ?>

<nav class="navigation">
<!-- moble menu --> 
	<div class="toggle-wrapper">
        <div class="menu-toggle inactive">
          <div class="bar"></div>
          <div class="bar"></div>
          <div class="bar"></div>
          <span class="bg"></span>
        </div>
        <p>MENU</p>
    </div>
    <a href="/">
		<img src="<?php echo $this->getThemePath(); ?>/img/perrone-logo.png" class="logo"/>
	</a>
	
