<?php defined('C5_EXECUTE') or die("Access Denied."); ?>

<footer>
	<div class="container">
		<div>
			<h2>EUROPE</h2>
			<p><strong>France:</strong> Nicolas Pavoine<br />
			+33.687.926.904</p>
			<p><strong>Germany:</strong> Antonio Jonasson<br />
			+1.518.853.4300 x 103</p>
		</div>
		<div>
			<div>
				<p><strong>Your contacts for<br /> more information</strong></p>
			</div>
			<div class="inner">
				<h2>USA</h2>
				<p>+1.518.853.4300</p>
			</div>
		</div>
		<div>
			<h2>ASIA</h2>
			<p>Peter Ong<br />
			+011.65.8826.1785</p>
			<p>France: Alexis Poulain<br />
			+33.642.586.111</p>
		</div>
	</div>
</footer>

<?php $this->inc('elements/footer_bottom.php');?>
