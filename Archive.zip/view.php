<?php print $innercontent; ?>

